package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.components.CreatorBottomNavBar
import com.example.ui.components.CreatorTopAppBar
import com.example.ui.screens.CreateScreen
import com.example.ui.screens.SavedScreen
import com.example.ui.screens.ViralIdeasScreen
import com.example.ui.theme.CreatorAiTheme
import com.example.ui.viewmodel.CreatorViewModel
import com.example.ui.viewmodel.ScreenTab

import com.example.ui.screens.PremiumPaywallSheet

class MainActivity : ComponentActivity() {
    private val viewModel: CreatorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            val currentTab by viewModel.currentTab.collectAsState()
            val savedScripts by viewModel.savedScripts.collectAsState()
            val snackbarMessage by viewModel.snackbarMessage.collectAsState()
            val subscriptionState by viewModel.subscriptionState.collectAsState()
            val isPaywallOpen by viewModel.isPaywallOpen.collectAsState()

            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(snackbarMessage) {
                snackbarMessage?.let { msg ->
                    snackbarHostState.showSnackbar(msg)
                    viewModel.clearSnackbar()
                }
            }

            CreatorAiTheme(darkTheme = isDarkMode) {
                // Predictive back handling: if in Saved or Viral Ideas, navigate back to Create
                if (currentTab != ScreenTab.CREATE) {
                    BackHandler {
                        viewModel.selectTab(ScreenTab.CREATE)
                    }
                }

                // Premium Paywall Sheet Modal
                if (isPaywallOpen) {
                    PremiumPaywallSheet(
                        subscriptionState = subscriptionState,
                        onDismiss = { viewModel.closePaywall() },
                        onSubscribe = { plan -> viewModel.subscribePlan(plan) },
                        onCancelSubscription = { viewModel.cancelSubscription() }
                    )
                }

                Scaffold(
                    topBar = {
                        CreatorTopAppBar(
                            isDarkMode = isDarkMode,
                            isPro = subscriptionState.isPro,
                            onToggleDarkMode = { viewModel.toggleDarkMode() },
                            onOpenPaywall = { viewModel.openPaywall() }
                        )
                    },
                    bottomBar = {
                        CreatorBottomNavBar(
                            currentTab = currentTab,
                            savedCount = savedScripts.size,
                            onSelectTab = { viewModel.selectTab(it) }
                        )
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    AnimatedContent(
                        targetState = currentTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tab_transition",
                        modifier = Modifier.padding(innerPadding)
                    ) { tab ->
                        when (tab) {
                            ScreenTab.CREATE -> CreateScreen(
                                viewModel = viewModel,
                                modifier = Modifier.fillMaxSize()
                            )
                            ScreenTab.SAVED -> SavedScreen(
                                viewModel = viewModel,
                                modifier = Modifier.fillMaxSize()
                            )
                            ScreenTab.VIRAL_IDEAS -> ViralIdeasScreen(
                                viewModel = viewModel,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }
    }
}
