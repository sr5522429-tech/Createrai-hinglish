package com.example.data

import com.example.model.DurationOption
import com.example.model.GeneratedScript
import com.example.model.Platform
import com.example.model.ScenePrompt
import com.example.model.ToneOption
import kotlinx.coroutines.delay
import java.util.UUID

interface AiRepository {
    suspend fun generateScript(
        topic: String,
        platform: Platform,
        duration: DurationOption,
        tone: ToneOption
    ): GeneratedScript
}

class TemplateAiRepository : AiRepository {
    override suspend fun generateScript(
        topic: String,
        platform: Platform,
        duration: DurationOption,
        tone: ToneOption
    ): GeneratedScript {
        // Realistic generation delay for polished UX
        delay(1300)

        val cleanTopic = topic.trim().ifBlank { "Desi Life Hacks" }
        val hooks = generateHooks(cleanTopic, tone)
        val voiceover = generateVoiceover(cleanTopic, platform, duration, tone)
        val scenes = generateScenes(cleanTopic, duration, tone)
        val caption = generateCaptionAndHashtags(cleanTopic, platform, tone)

        return GeneratedScript(
            id = UUID.randomUUID().toString(),
            topic = cleanTopic,
            platform = platform,
            duration = duration,
            tone = tone,
            createdAt = System.currentTimeMillis(),
            hooks = hooks,
            voiceoverScript = voiceover,
            scenePrompts = scenes,
            captionAndHashtags = caption
        )
    }

    private fun generateHooks(topic: String, tone: ToneOption): List<String> {
        return when (tone) {
            ToneOption.FUNNY_ROAST -> listOf(
                "🔥 Hook 1 (Shock / Roast): Agar tum abhi bhi sochte ho ki '$topic' normal hai... bhai tumhara system hi crash ho chuka hai! [Sarcastic smile]",
                "🔥 Hook 2 (POV Relatable): POV: Tum 2 ghante se '$topic' figure out karne ki koshish kar rahe ho, par dimaag me sirf dhuwaan nikal raha hai.",
                "🔥 Hook 3 (Desi Callout): Kisi ne bataya nahi tumhe? '$topic' par 99% log sabse badi galti karte hain, aur tum unhi 99% ke brand ambassador ho!"
            )
            ToneOption.INFORMATIVE -> listOf(
                "💡 Hook 1 (Curiosity Gap): Agar tum '$topic' ke baare me yeh 3 secret hacks jaan lo, toh agle 30 din me tumhara game pura badal jayega.",
                "💡 Hook 2 (Statistical Shock): 90% log '$topic' ko completely galat tareeqe se approach karte hain. Sahi formula sirf 2 minute me samjho.",
                "💡 Hook 3 (Actionable Hook): Save karlo yeh video right now! '$topic' ka yeh simple framework koi bada creator tumhe free me nahi batayega."
            )
            ToneOption.EMOTIONAL -> listOf(
                "❤️ Hook 1 (Heart Connect): Sach batao... kya kabhi akele baith kar tumne '$topic' ke baare me socha hai aur andar se thoda darr laga hai?",
                "❤️ Hook 2 (Validation): Agar tum abhi '$topic' ki struggle se guzar rahe ho, toh yaad rakhna: You are not alone, aur yeh phase hamesha ke liye nahi hai.",
                "❤️ Hook 3 (Storyline Hook): 2 saal pehle main bhi '$topic' ke samne bilkul hopeless tha... par fir ek chiz ne meri poori soch badal di."
            )
            ToneOption.SUSPENSE_FACT -> listOf(
                "🕵️‍♂️ Hook 1 (Mystery Question): Kya tumhe pata hai ki '$topic' ke peeche ka dark truth internet par kyu chupaya jata hai? [Dramatic pause]",
                "🕵️‍♂️ Hook 2 (Mind-Bender): Is video ko end tak dekhne ke baad, tum '$topic' ko dobara kabhi pehle jaise nazar se nahi dekh paoge.",
                "🕵️‍♂️ Hook 3 (Twist Warning): Ek aisi reality jo 2026 me '$topic' ko humesha ke liye badal chuki hai... aur yeh report sabke hosh uda degi!"
            )
        }
    }

    private fun generateVoiceover(
        topic: String,
        platform: Platform,
        duration: DurationOption,
        tone: ToneOption
    ): String {
        val platformCallout = if (platform == Platform.YOUTUBE_SHORTS) "Shorts feed" else "Reels explore"
        return when (duration) {
            DurationOption.SEC_30 -> """
[Energetic Hook - 0:00]
Bhai seedhi baat no bakwaas! [Pause] Agar tum '$topic' ko lekar serious ho, toh agle 30 seconds dhyan se sunna.

[Body - 0:08]
Log ghanto scroll karte hain is $platformCallout par, par asli value miss kar dete hain. 
Pehli galti: bina research ke jump karna. 
Dusri galti: overthink karke kuch na karna! [Excited gesture]

[Climax / Resolution - 0:20]
Aaj se rule simple hai: Start small, execute daily, and watch the compounding magic happen. [Pause]

[CTA - 0:26]
Comment me likho 'TRUTH' agar relate kiya, aur abhi share karo apne us dost ke sath jisko iski sabse zyada zaroorat hai! [Smile & Wink]
            """.trimIndent()

            DurationOption.SEC_45 -> """
[Opening Hook - 0:00]
Ruko ruko! [Quick freeze frame] Phone neeche mat scroll karna. Kyunki '$topic' ke baare me jo sach main batane wala hu, woh tumhara perspective hilane wala hai! [Excited]

[The Core Problem - 0:09]
Hum sab daily is trap me faste hain. Subah uthte hain, plan banate hain, par dopahar hote hote '$topic' ka sara motivation gayab! [Pause]
Kyu? Kyunki problem tumhari will-power me nahi hai boss, problem us system me hai jo hum follow kar rahe hain.

[Actionable Insight - 0:22]
Ab dhyan se suno solution: [Whisper mode]
Step 1: Apne goals ko break karo micro-actions me.
Step 2: Compare karna band karo internet ke fake perfection se.
Step 3: Track karo daily progress, chahe sirf 1% hi kyu na ho! [Excited punch]

[Punchline & Outro - 0:38]
Duniya results dekhti hai, par tumhari mehnat universe note karta hai. [Deep pause]
Save this reel right now taaki baad me bhool na jao, and follow for more raw insights!
            """.trimIndent()

            DurationOption.SEC_60 -> """
[Cinematic Hook - 0:00]
Ek baat notice ki hai tumne? [Dramatic pause] Jab bhi '$topic' ki baat aati hai, har koi gyan dene lagta hai... par actual ground reality koi nahi batata. [Serious eye contact]

[The Context & Conflict - 0:11]
Story simple hai: Hum hamesha soch rahe the ki sab kuch perfect time par hoga.
'Jab paisa hoga tab karenge', 'Jab time milega tab sochenge'. 
Lekin reality yeh hai ki woh 'perfect time' kabhi aata hi nahi! [Pause]
Aap '$topic' ko postpone karte ho, aur piche se time silently nikal jata hai.

[The Breakdown - 0:28]
Chalo aaj isko logically decode karte hain: [Excited pace]
Point number one: Jisko tum sabse badi difficulty samajh rahe ho, woh actually sabse basic step hai.
Point number two: Log kya sochenge? [Roast tone] Bhai log apna EMI pay karne me busy hain, unke paas tumpe judge karne ka time nahi hai!
Point number three: Consistency over brilliance. Roz ka ek ghanta kisi bhi talent ko beat kar sakta hai.

[Heartfelt Conclusion - 0:48]
Isliye aaj decide karo: Kya tum audience banna chahte ho, ya game ka creator? [Pause]
Faisla tumhara hai, par mauka dobara nahi aayega.

[Call to Action - 0:54]
Agar is baat ne dil ko chua ho, toh double tap karo aur apne close group me bhej ke unko bhi awaken karo. Comment your city below! [Warm smile]
            """.trimIndent()
        }
    }

    private fun generateScenes(
        topic: String,
        duration: DurationOption,
        tone: ToneOption
    ): List<ScenePrompt> {
        return listOf(
            ScenePrompt(
                sceneNumber = 1,
                timestamp = "0:00 - 0:07",
                visualPrompt = "Cinematic extreme close-up of a dynamic creator looking directly into lens, dramatic rim lighting in electric violet and teal, fast motion blur zoom-in, 8k hyper-realistic, photorealistic YouTube vertical style.",
                audioHinglish = "Bhai seedhi baat no bakwaas! '$topic' ke baare me dhyan se sunna..."
            ),
            ScenePrompt(
                sceneNumber = 2,
                timestamp = "0:07 - 0:18",
                visualPrompt = "Split-screen visual: Left side showing frustrated young adult checking phone screen with red glowing notification icons, Right side showing chaotic messy desk, desaturated moody color grading, cinematic depth of field.",
                audioHinglish = "Log ghanto scroll karte hain par problem system me hai..."
            ),
            ScenePrompt(
                sceneNumber = 3,
                timestamp = "0:18 - 0:32",
                visualPrompt = "Fast 3D motion graphic animation of glowing data cards, step-by-step floating icons in neon cyan, holographic UI elements overlaying modern Indian apartment background, vibrant lighting.",
                audioHinglish = "Step 1: Micro actions. Step 2: Compare karna band karo..."
            ),
            ScenePrompt(
                sceneNumber = 4,
                timestamp = if (duration == DurationOption.SEC_30) "0:25 - 0:30" else "0:32 - 0:45",
                visualPrompt = "Inspiring hero shot of young confident individual smiling against golden hour city skyline, warm anamorphic lens flare, smooth upward drone pan, cinematic vertical 9:16 aspect ratio.",
                audioHinglish = "Save karlo abhi, and follow for more real insights!"
            )
        )
    }

    private fun generateCaptionAndHashtags(
        topic: String,
        platform: Platform,
        tone: ToneOption
    ): String {
        val platformTag = if (platform == Platform.YOUTUBE_SHORTS) "#shorts #youtubeshorts" else "#reels #reelsinstagram"
        return """
✨ "$topic" ka pura sach in just 45 seconds! 

Agar relate kiya toh Double Tap ❤️ karna mat bhoolna. Tum iske baare me kya sochte ho? Tell me in the comments below 👇

📌 Save this post for when you need a reality check!
🚀 Tag that one friend jo relate karega!

$platformTag #creatorai #hinglishcreator #desicreator #viralvideo #contentcreator #indiancreators #trendingnow #growthhacks #viralreels #dailyinsights
        """.trimIndent()
    }
}
