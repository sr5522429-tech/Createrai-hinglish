package com.example.data

import com.example.model.DurationOption
import com.example.model.Platform
import com.example.model.ToneOption
import com.example.model.ViralIdea

object ViralIdeaBank {
    val categories = listOf(
        "All",
        "Tech & AI",
        "Money & Hustle",
        "Desi Comedy",
        "Hostel & College",
        "Psychology & Life"
    )

    val ideas: List<ViralIdea> = listOf(
        ViralIdea(
            id = "idea_1",
            topic = "iPhone 16 vs S24 Ultra - Middle Class Roast",
            category = "Tech & AI",
            suggestedPlatform = Platform.INSTAGRAM_REELS,
            suggestedDuration = DurationOption.SEC_45,
            suggestedTone = ToneOption.FUNNY_ROAST,
            whyViral = "High search volume on gadget upgrades with relatable EMI jokes.",
            sampleHook = "Agar tum bhi 80 hazaar ka phone sirf WhatsApp aur reels chalane ke liye lene wale ho... ruk jao!"
        ),
        ViralIdea(
            id = "idea_2",
            topic = "3 Free AI Websites jo College Assignments 2 min me khatam karengi",
            category = "Tech & AI",
            suggestedPlatform = Platform.YOUTUBE_SHORTS,
            suggestedDuration = DurationOption.SEC_30,
            suggestedTone = ToneOption.INFORMATIVE,
            whyViral = "High save-rate content for students and early professionals.",
            sampleHook = "Professor ko pata bhi nahi chalega ki assignment tumne likha ya super AI bot ne..."
        ),
        ViralIdea(
            id = "idea_3",
            topic = "Credit Card Trap: Kaise banks tumhe 'Free Rewards' ke naam par loot rahe hain",
            category = "Money & Hustle",
            suggestedPlatform = Platform.YOUTUBE_SHORTS,
            suggestedDuration = DurationOption.SEC_60,
            suggestedTone = ToneOption.SUSPENSE_FACT,
            whyViral = "Reveals hidden banking psychology, triggers comments and debates.",
            sampleHook = "Woh 'Free Airport Lounge Access' actually free nahi hai boss. Yeh calculation dekh ke dimaag hil jayega!"
        ),
        ViralIdea(
            id = "idea_4",
            topic = "Salary aate hi 5th day par 'Kahan gaya paisa?' Moment",
            category = "Money & Hustle",
            suggestedPlatform = Platform.INSTAGRAM_REELS,
            suggestedDuration = DurationOption.SEC_30,
            suggestedTone = ToneOption.FUNNY_ROAST,
            whyViral = "Extreme relatable pain point for 20-30 age demographic in metro cities.",
            sampleHook = "1st ko lagta hai Ambani ban gaye, aur 6th ko lagta hai Zomato delivery boy se udhaar mangna padega..."
        ),
        ViralIdea(
            id = "idea_5",
            topic = "Indian Parents explaining 'Sharma Ji ka Beta' Logic",
            category = "Desi Comedy",
            suggestedPlatform = Platform.INSTAGRAM_REELS,
            suggestedDuration = DurationOption.SEC_45,
            suggestedTone = ToneOption.FUNNY_ROAST,
            whyViral = "Universal Indian household experience, drives massive shares on WhatsApp.",
            sampleHook = "Sharma ji ka beta actually exist karta hai ya yeh bas Indian parents ka universal fear-mongering bot hai?!"
        ),
        ViralIdea(
            id = "idea_6",
            topic = "Engineering College Hostel Room at 2:30 AM",
            category = "Hostel & College",
            suggestedPlatform = Platform.INSTAGRAM_REELS,
            suggestedDuration = DurationOption.SEC_45,
            suggestedTone = ToneOption.EMOTIONAL,
            whyViral = "Nostalgia and camaraderie; triggers comment tagging of old college buddies.",
            sampleHook = "Ek electric kettle, 4 dost, aur aadhi raat ki Maggi... yeh amiri kisi 5-star hotel me nahi milti."
        ),
        ViralIdea(
            id = "idea_7",
            topic = "Night Before Exam: Syllabus dekh kar achanak spiritual realization",
            category = "Hostel & College",
            suggestedPlatform = Platform.YOUTUBE_SHORTS,
            suggestedDuration = DurationOption.SEC_30,
            suggestedTone = ToneOption.FUNNY_ROAST,
            whyViral = "High engagement during semester exams and entrance preparation seasons.",
            sampleHook = "Kal paper hai aur aaj syllabus dekh kar pata chala ki professor ne pura saal syllabus ke bahar padhaya tha!"
        ),
        ViralIdea(
            id = "idea_8",
            topic = "Why you feel exhausted even after sleeping 9 hours (Sleep Inertia)",
            category = "Psychology & Life",
            suggestedPlatform = Platform.YOUTUBE_SHORTS,
            suggestedDuration = DurationOption.SEC_45,
            suggestedTone = ToneOption.SUSPENSE_FACT,
            whyViral = "Curiosity gap that resonates with anyone struggling with morning lethargy.",
            sampleHook = "Agar tum 8 ghante sone ke baad bhi uthte hi thake huye feel karte ho, toh dikkat neend me nahi, is ek choti mistake me hai."
        ),
        ViralIdea(
            id = "idea_9",
            topic = "Dost jo bill split karne time bathroom chale jaate hain",
            category = "Desi Comedy",
            suggestedPlatform = Platform.INSTAGRAM_REELS,
            suggestedDuration = DurationOption.SEC_30,
            suggestedTone = ToneOption.FUNNY_ROAST,
            whyViral = "Instant tag magnet in friends groups and college gangs.",
            sampleHook = "Duniya ka sabse accurate biological clock inka hota hai: jaise hi waiter bill layega, inka digestion trigger ho jayega!"
        ),
        ViralIdea(
            id = "idea_10",
            topic = "Why 99% of people quit their gym goal after 21 days",
            category = "Psychology & Life",
            suggestedPlatform = Platform.YOUTUBE_SHORTS,
            suggestedDuration = DurationOption.SEC_60,
            suggestedTone = ToneOption.EMOTIONAL,
            whyViral = "Motivational mindset flip, encourages people not to give up on their habits.",
            sampleHook = "Yeh jo '21 days habit myth' hai na, isne lakhon logon ka confidence toda hai. Asli science suno..."
        ),
        ViralIdea(
            id = "idea_11",
            topic = "Deepfake Scams in India: Aise pehchano fake voice call",
            category = "Tech & AI",
            suggestedPlatform = Platform.YOUTUBE_SHORTS,
            suggestedDuration = DurationOption.SEC_45,
            suggestedTone = ToneOption.SUSPENSE_FACT,
            whyViral = "Urgent public safety issue, heavily forwarded to family WhatsApp groups.",
            sampleHook = "Kal subah tumhare paas tumhare best friend ki aawaz me emergency call aa sakti hai... Par paise transfer mat karna!"
        ),
        ViralIdea(
            id = "idea_12",
            topic = "First Job Struggle: 3 LPA vs 25 LPA Reality Check",
            category = "Money & Hustle",
            suggestedPlatform = Platform.INSTAGRAM_REELS,
            suggestedDuration = DurationOption.SEC_60,
            suggestedTone = ToneOption.EMOTIONAL,
            whyViral = "Strong emotional validation for tier 2/3 freshers entering the corporate grind.",
            sampleHook = "LinkedIn par har dusra banda 30 LPA ka package flaunt kar raha hai, par sach yeh hai..."
        )
    )

    fun getRandomIdea(): ViralIdea = ideas.random()
}
