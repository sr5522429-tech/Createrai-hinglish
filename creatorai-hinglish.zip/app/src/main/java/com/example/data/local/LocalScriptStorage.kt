package com.example.data.local

import android.content.Context
import android.util.Log
import com.example.model.DurationOption
import com.example.model.GeneratedScript
import com.example.model.Platform
import com.example.model.ScenePrompt
import com.example.model.ToneOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LocalScriptStorage(private val context: Context) {
    private val fileName = "creator_saved_scripts.json"
    private val _savedScripts = MutableStateFlow<List<GeneratedScript>>(emptyList())
    val savedScripts: StateFlow<List<GeneratedScript>> = _savedScripts.asStateFlow()

    init {
        loadFromDisk()
    }

    fun isSaved(id: String): Boolean {
        return _savedScripts.value.any { it.id == id }
    }

    suspend fun saveScript(script: GeneratedScript): Boolean = withContext(Dispatchers.IO) {
        val current = _savedScripts.value.toMutableList()
        // If already exists, replace or don't duplicate
        val existingIndex = current.indexOfFirst { it.id == script.id }
        if (existingIndex >= 0) {
            current[existingIndex] = script
        } else {
            current.add(0, script) // Add to top
        }
        _savedScripts.value = current
        writeToDisk(current)
        true
    }

    suspend fun deleteScript(id: String): Boolean = withContext(Dispatchers.IO) {
        val current = _savedScripts.value.toMutableList()
        val removed = current.removeAll { it.id == id }
        if (removed) {
            _savedScripts.value = current
            writeToDisk(current)
        }
        removed
    }

    private fun loadFromDisk() {
        try {
            val file = File(context.filesDir, fileName)
            if (!file.exists()) {
                _savedScripts.value = emptyList()
                return
            }
            val content = file.readText()
            if (content.isBlank()) {
                _savedScripts.value = emptyList()
                return
            }
            val jsonArray = JSONArray(content)
            val list = mutableListOf<GeneratedScript>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val hooksArray = obj.getJSONArray("hooks")
                val hooks = (0 until hooksArray.length()).map { hooksArray.getString(it) }

                val scenesArray = obj.getJSONArray("scenes")
                val scenes = (0 until scenesArray.length()).map { sIdx ->
                    val sObj = scenesArray.getJSONObject(sIdx)
                    ScenePrompt(
                        sceneNumber = sObj.getInt("sceneNumber"),
                        timestamp = sObj.getString("timestamp"),
                        visualPrompt = sObj.getString("visualPrompt"),
                        audioHinglish = sObj.getString("audioHinglish")
                    )
                }

                list.add(
                    GeneratedScript(
                        id = obj.getString("id"),
                        topic = obj.getString("topic"),
                        platform = Platform.fromString(obj.getString("platform")),
                        duration = DurationOption.fromString(obj.getString("duration")),
                        tone = ToneOption.fromString(obj.getString("tone")),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        hooks = hooks,
                        voiceoverScript = obj.getString("voiceoverScript"),
                        scenePrompts = scenes,
                        captionAndHashtags = obj.getString("captionAndHashtags")
                    )
                )
            }
            _savedScripts.value = list
        } catch (e: Exception) {
            Log.e("LocalScriptStorage", "Error loading saved scripts", e)
            _savedScripts.value = emptyList()
        }
    }

    private fun writeToDisk(scripts: List<GeneratedScript>) {
        try {
            val jsonArray = JSONArray()
            for (script in scripts) {
                val obj = JSONObject()
                obj.put("id", script.id)
                obj.put("topic", script.topic)
                obj.put("platform", script.platform.name)
                obj.put("duration", script.duration.name)
                obj.put("tone", script.tone.name)
                obj.put("createdAt", script.createdAt)
                obj.put("voiceoverScript", script.voiceoverScript)
                obj.put("captionAndHashtags", script.captionAndHashtags)

                val hooksArray = JSONArray()
                script.hooks.forEach { hooksArray.put(it) }
                obj.put("hooks", hooksArray)

                val scenesArray = JSONArray()
                script.scenePrompts.forEach { scene ->
                    val sObj = JSONObject()
                    sObj.put("sceneNumber", scene.sceneNumber)
                    sObj.put("timestamp", scene.timestamp)
                    sObj.put("visualPrompt", scene.visualPrompt)
                    sObj.put("audioHinglish", scene.audioHinglish)
                    scenesArray.put(sObj)
                }
                obj.put("scenes", scenesArray)

                jsonArray.put(obj)
            }

            val file = File(context.filesDir, fileName)
            file.writeText(jsonArray.toString(2))
        } catch (e: Exception) {
            Log.e("LocalScriptStorage", "Error writing saved scripts", e)
        }
    }
}
