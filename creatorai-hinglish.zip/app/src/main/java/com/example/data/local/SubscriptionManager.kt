package com.example.data.local

import android.content.Context
import com.example.model.PlanType
import com.example.model.SubscriptionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

class SubscriptionManager(context: Context) {
    private val prefs = context.getSharedPreferences("creator_subscription_prefs", Context.MODE_PRIVATE)

    private val _subscriptionState = MutableStateFlow(loadState())
    val subscriptionState: StateFlow<SubscriptionState> = _subscriptionState.asStateFlow()

    private fun loadState(): SubscriptionState {
        val isPro = prefs.getBoolean("is_pro", false)
        val planName = prefs.getString("plan_type", PlanType.FREE.name) ?: PlanType.FREE.name
        val expiry = prefs.getLong("expiry_timestamp", 0L)
        val plan = PlanType.fromString(planName)

        // Check if plan has expired
        val now = System.currentTimeMillis()
        val isStillActive = isPro && (expiry == 0L || expiry > now)

        val lastCreditDate = prefs.getString("last_credit_date", "")
        val todayDate = getTodayDateKey()
        val usedCredits = if (lastCreditDate == todayDate) {
            prefs.getInt("credits_used_today", 0)
        } else {
            0
        }

        val remainingCredits = if (isStillActive) 999 else (5 - usedCredits).coerceAtLeast(0)

        return SubscriptionState(
            isPro = isStillActive,
            planType = if (isStillActive) plan else PlanType.FREE,
            expiryTimestamp = expiry,
            remainingDailyCredits = remainingCredits
        )
    }

    fun subscribe(plan: PlanType) {
        val now = System.currentTimeMillis()
        val durationDays = if (plan == PlanType.YEARLY) 365L else 30L
        val expiry = now + (durationDays * 24L * 60L * 60L * 1000L)

        prefs.edit()
            .putBoolean("is_pro", true)
            .putString("plan_type", plan.name)
            .putLong("expiry_timestamp", expiry)
            .apply()

        _subscriptionState.value = SubscriptionState(
            isPro = true,
            planType = plan,
            expiryTimestamp = expiry,
            remainingDailyCredits = 999
        )
    }

    fun cancelSubscription() {
        prefs.edit()
            .putBoolean("is_pro", false)
            .putString("plan_type", PlanType.FREE.name)
            .putLong("expiry_timestamp", 0L)
            .apply()

        _subscriptionState.value = SubscriptionState(
            isPro = false,
            planType = PlanType.FREE,
            expiryTimestamp = 0L,
            remainingDailyCredits = 5
        )
    }

    fun useCredit(): Boolean {
        val current = _subscriptionState.value
        if (current.isPro) return true // Unlimited for pro!

        val todayDate = getTodayDateKey()
        val lastCreditDate = prefs.getString("last_credit_date", "")
        var used = if (lastCreditDate == todayDate) prefs.getInt("credits_used_today", 0) else 0

        if (used >= 5) {
            return false // No credits left today
        }

        used += 1
        prefs.edit()
            .putString("last_credit_date", todayDate)
            .putInt("credits_used_today", used)
            .apply()

        _subscriptionState.value = current.copy(
            remainingDailyCredits = (5 - used).coerceAtLeast(0)
        )
        return true
    }

    private fun getTodayDateKey(): String {
        val cal = Calendar.getInstance()
        return "${cal.get(Calendar.YEAR)}_${cal.get(Calendar.MONTH)}_${cal.get(Calendar.DAY_OF_MONTH)}"
    }
}
