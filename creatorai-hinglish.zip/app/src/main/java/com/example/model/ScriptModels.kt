package com.example.model

import java.util.UUID

enum class Platform(val displayName: String, val shortName: String, val badgeIcon: String) {
    YOUTUBE_SHORTS("YouTube Shorts", "Shorts", "▶️"),
    INSTAGRAM_REELS("Instagram Reels", "Reels", "📸");

    companion object {
        fun fromString(value: String): Platform =
            entries.find { it.name.equals(value, ignoreCase = true) || it.displayName.equals(value, ignoreCase = true) }
                ?: YOUTUBE_SHORTS
    }
}

enum class DurationOption(val label: String, val seconds: Int, val pacing: String) {
    SEC_30("30 Sec", 30, "Fast & Punchy"),
    SEC_45("45 Sec", 45, "Standard Viral"),
    SEC_60("60 Sec", 60, "Deep Dive Story");

    companion object {
        fun fromString(value: String): DurationOption =
            entries.find { it.name.equals(value, ignoreCase = true) || it.label.equals(value, ignoreCase = true) }
                ?: SEC_45
    }
}

enum class ToneOption(val label: String, val emoji: String, val description: String) {
    FUNNY_ROAST("Funny / Roast", "🔥", "Relatable savage sarcasm & desi jokes"),
    INFORMATIVE("Informative", "💡", "Clear value-first tips & facts"),
    EMOTIONAL("Emotional", "❤️", "Heartfelt relatable struggle & motivation"),
    SUSPENSE_FACT("Suspense / Fact", "🕵️‍♂️", "Curiosity loop & mind-blowing revelations");

    companion object {
        fun fromString(value: String): ToneOption =
            entries.find { it.name.equals(value, ignoreCase = true) || it.label.equals(value, ignoreCase = true) }
                ?: FUNNY_ROAST
    }
}

data class ScenePrompt(
    val sceneNumber: Int,
    val timestamp: String,
    val visualPrompt: String,
    val audioHinglish: String
)

data class GeneratedScript(
    val id: String = UUID.randomUUID().toString(),
    val topic: String,
    val platform: Platform,
    val duration: DurationOption,
    val tone: ToneOption,
    val createdAt: Long = System.currentTimeMillis(),
    val hooks: List<String>,
    val voiceoverScript: String,
    val scenePrompts: List<ScenePrompt>,
    val captionAndHashtags: String
)

data class ViralIdea(
    val id: String,
    val topic: String,
    val category: String,
    val suggestedPlatform: Platform,
    val suggestedDuration: DurationOption,
    val suggestedTone: ToneOption,
    val whyViral: String,
    val sampleHook: String
)

enum class PlanType(
    val title: String,
    val priceDisplay: String,
    val billingPeriod: String,
    val rawPrice: Int,
    val monthlyEquivalent: String,
    val discountBadge: String?
) {
    FREE("Free Plan", "₹0", "Forever", 0, "₹0/mo", null),
    MONTHLY("Monthly Pro", "₹99", "per month", 99, "₹99/mo", null),
    YEARLY("Yearly Pro", "₹799", "per year", 799, "₹66/mo", "SAVE 33% • BEST VALUE 🔥");

    companion object {
        fun fromString(value: String): PlanType =
            entries.find { it.name.equals(value, ignoreCase = true) } ?: FREE
    }
}

data class SubscriptionState(
    val isPro: Boolean = false,
    val planType: PlanType = PlanType.FREE,
    val expiryTimestamp: Long = 0L,
    val remainingDailyCredits: Int = 5
)

