package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DurationOption
import com.example.model.GeneratedScript
import com.example.model.Platform
import com.example.model.ToneOption
import com.example.ui.components.CardActionRow
import com.example.ui.components.copyToClipboard
import com.example.ui.components.shareToWhatsApp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.InstagramPurple
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.theme.YouTubeRed
import com.example.ui.viewmodel.CreatorViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateScreen(
    viewModel: CreatorViewModel,
    modifier: Modifier = Modifier
) {
    val topicText by viewModel.topicText.collectAsState()
    val selectedPlatform by viewModel.selectedPlatform.collectAsState()
    val selectedDuration by viewModel.selectedDuration.collectAsState()
    val selectedTone by viewModel.selectedTone.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val currentScript by viewModel.currentScript.collectAsState()
    val savedScripts by viewModel.savedScripts.collectAsState()

    val isCurrentSaved = currentScript?.let { script ->
        savedScripts.any { it.id == script.id }
    } ?: false

    val context = LocalContext.current

    val subscriptionState by viewModel.subscriptionState.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Subscription Tier Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (subscriptionState.isPro) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.openPaywall() }
                    .testTag("subscription_tier_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(if (subscriptionState.isPro) "👑" else "⚡", fontSize = 16.sp)
                        Column {
                            Text(
                                text = if (subscriptionState.isPro)
                                    "${subscriptionState.planType.title} • Unlimited"
                                else
                                    "Free Tier: ${subscriptionState.remainingDailyCredits}/5 credits left today",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (subscriptionState.isPro) Color(0xFFB45309) else MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = if (subscriptionState.isPro) "All 4 cards generated with Pro quality" else "Upgrade to PRO (₹99/mo or ₹799/yr) for unlimited",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (subscriptionState.isPro) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (subscriptionState.isPro) Color(0xFFF59E0B) else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text(
                            text = if (subscriptionState.isPro) "ACTIVE" else "Upgrade 🚀",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Notice Banner explaining Firebase status
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Notice",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Curated AI Engine active. (Live Gemini 3.8 Flash model calls in Android apps require Firebase setup).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // --- FORM SECTION ---
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Title & Random Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "💡 Video Topic",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )

                        OutlinedButton(
                            onClick = { viewModel.pickRandomIdea() },
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("random_idea_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Casino,
                                contentDescription = "Random Idea",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Random Idea", fontSize = 12.sp)
                        }
                    }

                    // Input Field
                    OutlinedTextField(
                        value = topicText,
                        onValueChange = { viewModel.setTopic(it) },
                        placeholder = { Text("e.g. Chai vs Coffee roast, 5 money traps...") },
                        trailingIcon = {
                            if (topicText.isNotBlank()) {
                                IconButton(onClick = { viewModel.setTopic("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("topic_input_field"),
                        minLines = 2,
                        maxLines = 3
                    )

                    // Platform Selector
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Target Platform",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Platform.entries.forEach { platform ->
                                val isSelected = selectedPlatform == platform
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.setPlatform(platform) },
                                    label = { Text(platform.displayName) },
                                    leadingIcon = {
                                        Text(if (platform == Platform.YOUTUBE_SHORTS) "🔴" else "📸", fontSize = 12.sp)
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = if (platform == Platform.YOUTUBE_SHORTS)
                                            YouTubeRed.copy(alpha = 0.2f)
                                        else
                                            InstagramPurple.copy(alpha = 0.2f),
                                        selectedLabelColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("platform_chip_${platform.name.lowercase()}")
                                )
                            }
                        }
                    }

                    // Duration Selector
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Target Duration",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            DurationOption.entries.forEach { duration ->
                                val isSelected = selectedDuration == duration
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.setDuration(duration) },
                                    label = { Text(duration.label) },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("duration_chip_${duration.seconds}")
                                )
                            }
                        }
                    }

                    // Tone Selector
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Content Tone & Vibe",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            ToneOption.entries.forEach { tone ->
                                val isSelected = selectedTone == tone
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.setTone(tone) },
                                    label = { Text("${tone.emoji} ${tone.label}") },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("tone_chip_${tone.name.lowercase()}")
                                )
                            }
                        }
                    }

                    // Generate Button
                    Button(
                        onClick = { viewModel.generateScript() },
                        enabled = !isGenerating,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_script_button")
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Crafting Hinglish Script...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Generate Viral Script 🚀",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // --- 4 GENERATED SCRIPT CARDS ---
        currentScript?.let { script ->
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Generated Output",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${script.platform.displayName} • ${script.duration.label} • ${script.tone.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Button(
                        onClick = { viewModel.saveCurrentScript() },
                        shape = RoundedCornerShape(20.dp),
                        colors = if (isCurrentSaved) {
                            ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        } else {
                            ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        },
                        modifier = Modifier.testTag("save_script_button")
                    ) {
                        Icon(
                            imageVector = if (isCurrentSaved) Icons.Default.Check else Icons.Default.Bookmark,
                            contentDescription = "Save",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isCurrentSaved) "Saved" else "Save Script", fontSize = 13.sp)
                    }
                }
            }

            // Card 1: 3 Viral Hooks (Hinglish)
            item {
                ScriptCard(
                    title = "🔥 3 Viral Hooks (Hinglish)",
                    subtitle = "Scroll-stopping opening hooks to hook viewers in first 3 seconds",
                    badgeColor = Color(0xFFF97316)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        script.hooks.forEachIndexed { index, hook ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFF97316).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Color(0xFFF97316)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = hook,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            lineHeight = 20.sp
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        CardActionRow(
                            textToShare = script.hooks.joinToString("\n\n"),
                            label = "Viral Hooks"
                        )
                    }
                }
            }

            // Card 2: Full Voiceover Script (Hinglish)
            item {
                ScriptCard(
                    title = "🎙️ Full Voiceover Script (Hinglish)",
                    subtitle = "Conversational Hindi+English with pacing cues [Pause], [Excited]",
                    badgeColor = ElectricIndigo
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PacedVoiceoverText(script.voiceoverScript)

                        CardActionRow(
                            textToShare = script.voiceoverScript,
                            label = "Voiceover Script"
                        )
                    }
                }
            }

            // Card 3: Scene-by-Scene AI Video Prompts (English)
            item {
                ScriptCard(
                    title = "🎬 Scene-by-Scene AI Video Prompts",
                    subtitle = "Production-ready prompts for Midjourney, Runway, Pika & Sora",
                    badgeColor = ElectricCyan
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        script.scenePrompts.forEach { scene ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Scene ${scene.sceneNumber}",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = ElectricCyan
                                            )
                                        )
                                        Text(
                                            text = scene.timestamp,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = "Prompt: ${scene.visualPrompt}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "Audio: \"${scene.audioHinglish}\"",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }
                            }
                        }

                        val scenesText = script.scenePrompts.joinToString("\n\n") {
                            "Scene ${it.sceneNumber} (${it.timestamp}):\nAI Prompt: ${it.visualPrompt}\nAudio: ${it.audioHinglish}"
                        }

                        CardActionRow(
                            textToShare = scenesText,
                            label = "Scene Prompts"
                        )
                    }
                }
            }

            // Card 4: Caption & Trending Hashtags
            item {
                ScriptCard(
                    title = "#️⃣ Caption & Trending Hashtags",
                    subtitle = "Optimized caption copy with viral reach tags",
                    badgeColor = Color(0xFF10B981)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = script.captionAndHashtags,
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                                modifier = Modifier.padding(12.dp)
                            )
                        }

                        CardActionRow(
                            textToShare = script.captionAndHashtags,
                            label = "Caption and Hashtags"
                        )
                    }
                }
            }

            // Bottom Full Script Actions
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "📦 Full Package Export",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )

                        val fullPackageText = """
🚀 TOPIC: ${script.topic}
🎯 Platform: ${script.platform.displayName} | Duration: ${script.duration.label} | Tone: ${script.tone.label}

🔥 VIRAL HOOKS:
${script.hooks.joinToString("\n")}

🎙️ VOICEOVER SCRIPT:
${script.voiceoverScript}

🎬 SCENE-BY-SCENE AI PROMPTS:
${script.scenePrompts.joinToString("\n\n") { "Scene ${it.sceneNumber} (${it.timestamp}): ${it.visualPrompt}" }}

#️⃣ CAPTION & HASHTAGS:
${script.captionAndHashtags}
                        """.trimIndent()

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { copyToClipboard(context, fullPackageText, "Full Package") },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copy All")
                            }

                            Button(
                                onClick = { shareToWhatsApp(context, fullPackageText) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = WhatsAppGreen
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("💬", fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("WhatsApp All")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun ScriptCard(
    title: String,
    subtitle: String,
    badgeColor: Color,
    content: @Composable () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(badgeColor)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            content()
        }
    }
}

@Composable
fun PacedVoiceoverText(script: String) {
    // Style pacing cues in brackets like [Pause], [Excited], etc.
    val lines = script.lines()
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            lines.forEach { line ->
                val annotatedString = buildAnnotatedString {
                    var currentIndex = 0
                    val regex = Regex("\\[(.*?)\\]")
                    val matches = regex.findAll(line)

                    for (match in matches) {
                        if (match.range.first > currentIndex) {
                            append(line.substring(currentIndex, match.range.first))
                        }
                        withStyle(
                            style = SpanStyle(
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        ) {
                            append(match.value)
                        }
                        currentIndex = match.range.last + 1
                    }
                    if (currentIndex < line.length) {
                        append(line.substring(currentIndex))
                    }
                }

                Text(
                    text = annotatedString,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        lineHeight = 22.sp
                    )
                )
            }
        }
    }
}
