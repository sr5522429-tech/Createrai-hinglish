package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GeneratedScript
import com.example.ui.components.CardActionRow
import com.example.ui.components.copyToClipboard
import com.example.ui.components.shareToWhatsApp
import com.example.ui.theme.WhatsAppGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptDetailDialog(
    script: GeneratedScript,
    onDismiss: () -> Unit,
    onDelete: (GeneratedScript) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = script.topic,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${script.platform.displayName} • ${script.duration.label} • ${script.tone.label}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_detail_modal")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            HorizontalDivider()

            // 1. Viral Hooks
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔥 3 Viral Hooks", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    script.hooks.forEachIndexed { i, hook ->
                        Text("${i + 1}. $hook", style = MaterialTheme.typography.bodyMedium)
                    }
                    CardActionRow(textToShare = script.hooks.joinToString("\n"), label = "Hooks")
                }
            }

            // 2. Full Voiceover Script
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎙️ Full Voiceover Script", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    PacedVoiceoverText(script.voiceoverScript)
                    CardActionRow(textToShare = script.voiceoverScript, label = "Voiceover")
                }
            }

            // 3. Scene-by-Scene AI Prompts
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎬 Scene-by-Scene AI Prompts", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    script.scenePrompts.forEach { scene ->
                        Text("• Scene ${scene.sceneNumber} (${scene.timestamp}): ${scene.visualPrompt}", style = MaterialTheme.typography.bodySmall)
                    }
                    val scenesText = script.scenePrompts.joinToString("\n") { "Scene ${it.sceneNumber} (${it.timestamp}): ${it.visualPrompt}" }
                    CardActionRow(textToShare = scenesText, label = "Scenes")
                }
            }

            // 4. Caption & Hashtags
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("#️⃣ Caption & Hashtags", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(script.captionAndHashtags, style = MaterialTheme.typography.bodyMedium)
                    CardActionRow(textToShare = script.captionAndHashtags, label = "Caption")
                }
            }

            // Bottom Actions: Delete or Share Package
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { onDelete(script) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Delete")
                }

                Button(
                    onClick = {
                        val full = "Topic: ${script.topic}\n\nHooks:\n${script.hooks.joinToString("\n")}\n\nVoiceover:\n${script.voiceoverScript}\n\nCaption:\n${script.captionAndHashtags}"
                        shareToWhatsApp(context, full)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("💬", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp All")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
