package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accents
val ElectricIndigo = Color(0xFF6366F1)
val ElectricIndigoDark = Color(0xFF818CF8)
val ElectricCoral = Color(0xFFF43F5E)
val ElectricCyan = Color(0xFF06B6D4)
val GoldenAmber = Color(0xFFF59E0B)

// Dark Theme Colors
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkCardBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightCardBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// WhatsApp Brand Color for share button
val WhatsAppGreen = Color(0xFF25D366)
val YouTubeRed = Color(0xFFFF0000)
val InstagramPurple = Color(0xFFE1306C)
