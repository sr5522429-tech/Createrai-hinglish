package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiRepository
import com.example.data.TemplateAiRepository
import com.example.data.ViralIdeaBank
import com.example.data.local.LocalScriptStorage
import com.example.model.DurationOption
import com.example.model.GeneratedScript
import com.example.model.Platform
import com.example.model.ToneOption
import com.example.model.ViralIdea
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.local.SubscriptionManager
import com.example.model.PlanType
import com.example.model.SubscriptionState

enum class ScreenTab(val title: String) {
    CREATE("Create"),
    SAVED("Saved"),
    VIRAL_IDEAS("Viral Ideas")
}

class CreatorViewModel(application: Application) : AndroidViewModel(application) {
    private val localScriptStorage = LocalScriptStorage(application.applicationContext)
    private val subscriptionManager = SubscriptionManager(application.applicationContext)
    private val aiRepository: AiRepository = TemplateAiRepository()

    // Subscription State
    val subscriptionState: StateFlow<SubscriptionState> = subscriptionManager.subscriptionState
    private val _isPaywallOpen = MutableStateFlow(false)
    val isPaywallOpen: StateFlow<Boolean> = _isPaywallOpen.asStateFlow()

    // Navigation and theme
    private val _currentTab = MutableStateFlow(ScreenTab.CREATE)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Create Screen Form State
    private val _topicText = MutableStateFlow("Why Indian students drink chai at 2 AM")
    val topicText: StateFlow<String> = _topicText.asStateFlow()

    private val _selectedPlatform = MutableStateFlow(Platform.INSTAGRAM_REELS)
    val selectedPlatform: StateFlow<Platform> = _selectedPlatform.asStateFlow()

    private val _selectedDuration = MutableStateFlow(DurationOption.SEC_45)
    val selectedDuration: StateFlow<DurationOption> = _selectedDuration.asStateFlow()

    private val _selectedTone = MutableStateFlow(ToneOption.FUNNY_ROAST)
    val selectedTone: StateFlow<ToneOption> = _selectedTone.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _currentScript = MutableStateFlow<GeneratedScript?>(null)
    val currentScript: StateFlow<GeneratedScript?> = _currentScript.asStateFlow()

    // Snackbar / Toast feedback
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Saved Screen State
    val savedScripts = localScriptStorage.savedScripts

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _savedFilter = MutableStateFlow("All")
    val savedFilter: StateFlow<String> = _savedFilter.asStateFlow()

    val filteredSavedScripts: StateFlow<List<GeneratedScript>> = combine(
        savedScripts,
        _searchQuery,
        _savedFilter
    ) { scripts, query, filter ->
        scripts.filter { script ->
            val matchesQuery = query.isBlank() ||
                script.topic.contains(query, ignoreCase = true) ||
                script.voiceoverScript.contains(query, ignoreCase = true) ||
                script.captionAndHashtags.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                "Shorts" -> script.platform == Platform.YOUTUBE_SHORTS
                "Reels" -> script.platform == Platform.INSTAGRAM_REELS
                "Roast" -> script.tone == ToneOption.FUNNY_ROAST
                "Info" -> script.tone == ToneOption.INFORMATIVE
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Detail Modal / Sheet state
    private val _detailScript = MutableStateFlow<GeneratedScript?>(null)
    val detailScript: StateFlow<GeneratedScript?> = _detailScript.asStateFlow()

    // Delete Confirmation Dialog state
    private val _scriptPendingDelete = MutableStateFlow<GeneratedScript?>(null)
    val scriptPendingDelete: StateFlow<GeneratedScript?> = _scriptPendingDelete.asStateFlow()

    // Viral Ideas Screen State
    private val _selectedIdeaCategory = MutableStateFlow("All")
    val selectedIdeaCategory: StateFlow<String> = _selectedIdeaCategory.asStateFlow()

    val viralIdeas: List<ViralIdea> = ViralIdeaBank.ideas

    val filteredViralIdeas: StateFlow<List<ViralIdea>> = _selectedIdeaCategory.combine(_selectedIdeaCategory) { cat, _ ->
        if (cat == "All") viralIdeas else viralIdeas.filter { it.category == cat }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), viralIdeas)

    init {
        // Generate an initial attractive demo script so the Create tab has instant high-quality sample cards on launch!
        viewModelScope.launch {
            try {
                val initialScript = aiRepository.generateScript(
                    topic = _topicText.value,
                    platform = _selectedPlatform.value,
                    duration = _selectedDuration.value,
                    tone = _selectedTone.value
                )
                _currentScript.value = initialScript
            } catch (ignored: Exception) {}
        }
    }

    fun selectTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setTopic(topic: String) {
        _topicText.value = topic
    }

    fun setPlatform(platform: Platform) {
        _selectedPlatform.value = platform
    }

    fun setDuration(duration: DurationOption) {
        _selectedDuration.value = duration
    }

    fun setTone(tone: ToneOption) {
        _selectedTone.value = tone
    }

    fun pickRandomIdea() {
        val random = ViralIdeaBank.getRandomIdea()
        _topicText.value = random.topic
        _selectedPlatform.value = random.suggestedPlatform
        _selectedDuration.value = random.suggestedDuration
        _selectedTone.value = random.suggestedTone
        showSnackbar("🎲 Loaded: ${random.topic}")
    }

    fun useViralIdea(idea: ViralIdea) {
        _topicText.value = idea.topic
        _selectedPlatform.value = idea.suggestedPlatform
        _selectedDuration.value = idea.suggestedDuration
        _selectedTone.value = idea.suggestedTone
        _currentTab.value = ScreenTab.CREATE
        showSnackbar("💡 Idea applied! Ready to generate.")
    }

    fun openPaywall() {
        _isPaywallOpen.value = true
    }

    fun closePaywall() {
        _isPaywallOpen.value = false
    }

    fun subscribePlan(plan: PlanType) {
        subscriptionManager.subscribe(plan)
        _isPaywallOpen.value = false
        showSnackbar("👑 Welcome to ${plan.title}! Unlimited scripts active.")
    }

    fun cancelSubscription() {
        subscriptionManager.cancelSubscription()
        _isPaywallOpen.value = false
        showSnackbar("Subscription cancelled.")
    }

    fun generateScript() {
        val topic = _topicText.value.trim()
        if (topic.isBlank()) {
            showSnackbar("Please enter a video topic first!")
            return
        }

        // Check if free user has credits remaining
        if (!subscriptionManager.useCredit()) {
            showSnackbar("Daily free credits limit reached (5/5). Upgrade to PRO!")
            openPaywall()
            return
        }

        viewModelScope.launch {
            _isGenerating.value = true
            try {
                val script = aiRepository.generateScript(
                    topic = topic,
                    platform = _selectedPlatform.value,
                    duration = _selectedDuration.value,
                    tone = _selectedTone.value
                )
                _currentScript.value = script
                showSnackbar("✨ Viral script generated successfully!")
            } catch (e: Exception) {
                showSnackbar("Failed to generate: ${e.localizedMessage}")
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun isScriptSaved(id: String): Boolean {
        return localScriptStorage.isSaved(id)
    }

    fun saveCurrentScript() {
        val script = _currentScript.value ?: return
        viewModelScope.launch {
            localScriptStorage.saveScript(script)
            showSnackbar("💾 Script saved for offline access!")
        }
    }

    fun saveSpecificScript(script: GeneratedScript) {
        viewModelScope.launch {
            localScriptStorage.saveScript(script)
            showSnackbar("💾 Script saved!")
        }
    }

    fun requestDeleteScript(script: GeneratedScript) {
        _scriptPendingDelete.value = script
    }

    fun cancelDelete() {
        _scriptPendingDelete.value = null
    }

    fun confirmDelete() {
        val script = _scriptPendingDelete.value ?: return
        viewModelScope.launch {
            localScriptStorage.deleteScript(script.id)
            _scriptPendingDelete.value = null
            if (_detailScript.value?.id == script.id) {
                _detailScript.value = null
            }
            showSnackbar("🗑️ Script deleted.")
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSavedFilter(filter: String) {
        _savedFilter.value = filter
    }

    fun openDetailScript(script: GeneratedScript) {
        _detailScript.value = script
    }

    fun closeDetailScript() {
        _detailScript.value = null
    }

    fun setSelectedIdeaCategory(category: String) {
        _selectedIdeaCategory.value = category
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }
}
