package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.TemplateAiRepository
import com.example.data.ViralIdeaBank
import com.example.data.local.LocalScriptStorage
import com.example.model.DurationOption
import com.example.model.GeneratedScript
import com.example.model.Platform
import com.example.model.ScenePrompt
import com.example.model.ToneOption
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Script Master: AI Reels & Shorts", appName)
  }

  @Test
  fun `offline storage persists and deletes script correctly`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val storage = LocalScriptStorage(context)

    val script = GeneratedScript(
      id = UUID.randomUUID().toString(),
      topic = "Unit Test Script",
      platform = Platform.INSTAGRAM_REELS,
      duration = DurationOption.SEC_30,
      tone = ToneOption.FUNNY_ROAST,
      hooks = listOf("Hook 1", "Hook 2", "Hook 3"),
      voiceoverScript = "[Pause] Test voiceover script",
      scenePrompts = listOf(ScenePrompt(1, "0:00 - 0:05", "Camera pan", "Audio 1")),
      captionAndHashtags = "#test #viral"
    )

    // Save
    val saved = storage.saveScript(script)
    assertTrue(saved)
    assertTrue(storage.isSaved(script.id))
    assertEquals(1, storage.savedScripts.value.size)
    assertEquals("Unit Test Script", storage.savedScripts.value.first().topic)

    // Delete
    val deleted = storage.deleteScript(script.id)
    assertTrue(deleted)
    assertFalse(storage.isSaved(script.id))
    assertEquals(0, storage.savedScripts.value.size)
  }

  @Test
  fun `template ai repository generates complete 4 card package`() = runBlocking {
    val repo = TemplateAiRepository()
    val result = repo.generateScript(
      topic = "Chai vs Coffee",
      platform = Platform.YOUTUBE_SHORTS,
      duration = DurationOption.SEC_45,
      tone = ToneOption.FUNNY_ROAST
    )

    assertNotNull(result)
    assertEquals("Chai vs Coffee", result.topic)
    assertEquals(3, result.hooks.size)
    assertTrue(result.voiceoverScript.contains("[") && result.voiceoverScript.contains("]"))
    assertTrue(result.scenePrompts.isNotEmpty())
    assertTrue(result.captionAndHashtags.contains("#"))
  }

  @Test
  fun `viral idea bank contains ideas with proper categories`() {
    val ideas = ViralIdeaBank.ideas
    assertTrue(ideas.size >= 10)
    val random = ViralIdeaBank.getRandomIdea()
    assertNotNull(random.topic)
    assertNotNull(random.sampleHook)
  }

  @Test
  fun `subscription manager handles monthly and yearly plans`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val subManager = com.example.data.local.SubscriptionManager(context)

    // Initially free
    assertFalse(subManager.subscriptionState.value.isPro)
    assertEquals(com.example.model.PlanType.FREE, subManager.subscriptionState.value.planType)

    // Subscribe Monthly (₹99)
    subManager.subscribe(com.example.model.PlanType.MONTHLY)
    assertTrue(subManager.subscriptionState.value.isPro)
    assertEquals(com.example.model.PlanType.MONTHLY, subManager.subscriptionState.value.planType)
    assertEquals(99, subManager.subscriptionState.value.planType.rawPrice)

    // Subscribe Yearly (₹799)
    subManager.subscribe(com.example.model.PlanType.YEARLY)
    assertTrue(subManager.subscriptionState.value.isPro)
    assertEquals(com.example.model.PlanType.YEARLY, subManager.subscriptionState.value.planType)
    assertEquals(799, subManager.subscriptionState.value.planType.rawPrice)

    // Cancel
    subManager.cancelSubscription()
    assertFalse(subManager.subscriptionState.value.isPro)
  }
}

